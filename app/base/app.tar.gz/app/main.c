#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include "codestd.h"

/**************************************************************************************************
 * @brief  : 测试程序
 * @param  : None
 * @return : None
**************************************************************************************************/
int main(int argc, char const *argv[])
{
    LOG_I("hello world");
    return 0;
}