#ifndef __CODESTD_H__
#define __CODESTD_H__
__BEGIN_DECLS
#include "ckret.h"
#include "apey.h"
__END_DECLS
#endif
